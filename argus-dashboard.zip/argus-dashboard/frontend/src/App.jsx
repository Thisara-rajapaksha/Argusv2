import { useEffect, useState } from "react";

const call = (url, method = "GET", body) =>
  fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  }).then(r => r.json());

const when = ts => new Date(ts * 1000).toLocaleString();

function useHealth() {
  const [health, setHealth] = useState(null);
  useEffect(() => {
    const load = () => call("/api/health").then(setHealth).catch(() => setHealth(null));
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, []);
  return [health, setHealth];
}

function useEvents() {
  const [events, setEvents] = useState([]);
  useEffect(() => {
    call("/api/events").then(setEvents).catch(() => {});
    const es = new EventSource("/api/events/stream");          // new events arrive instantly
    es.onmessage = m => setEvents(list => [JSON.parse(m.data), ...list].slice(0, 100));
    return () => es.close();
  }, []);
  const mark = (id, falseAlarm) =>
    call(`/api/events/${id}/ack`, "POST", { false_alarm: falseAlarm }).then(r =>
      setEvents(list => list.map(e => (e.id === id ? { ...e, status: r.status } : e))));
  return [events, mark];
}

function EventCard({ e, mark }) {
  return (
    <article className={"event " + e.status}>
      {e.snapshot && <img src={e.snapshot} alt="Snapshot of the event" />}
      <div>
        <h3>{e.label}</h3>
        <p className="muted">{when(e.ts)} · {e.status.replace("_", " ")}</p>
        {e.status === "new" && (
          <div className="row">
            <button onClick={() => mark(e.id, false)}>Acknowledge</button>
            <button className="quiet" onClick={() => mark(e.id, true)}>Mark false alarm</button>
          </div>
        )}
      </div>
    </article>
  );
}

function Live({ health, events, mark, pickColor }) {
  return (
    <div className="split">
      <section>
        <div className={"stage" + (health?.alert ? " alert" : "")}>
          <img src="/api/cameras/1/stream" alt="Live camera view" />
        </div>
        <dl className="facts">
          <div><dt>Camera</dt><dd>{health ? (health.online ? "Online" : "No video") : "Backend not reachable"}</dd></div>
          <div><dt>Frame rate</dt><dd>{health ? `${health.fps} fps` : "-"}</dd></div>
          <div><dt>CPU temperature</dt><dd>{health?.cpu_temp != null ? `${health.cpu_temp} °C` : "Not available"}</dd></div>
          <div>
            <dt><label htmlFor="color">Watching for</label></dt>
            <dd>
              <select id="color" value={health?.color || "red"} disabled={!health || health.mode !== "color"}
                      onChange={e => pickColor(e.target.value)}>
                {["red", "orange", "yellow", "green", "blue"].map(c => (
                  <option key={c} value={c}>{c[0].toUpperCase() + c.slice(1)} objects</option>
                ))}
              </select>
            </dd>
          </div>
        </dl>
      </section>
      <section>
        <h2>Latest events</h2>
        {events.length === 0 && <p className="muted">Nothing yet. An alert appears here when the watched color stays in the zone.</p>}
        {events.slice(0, 5).map(e => <EventCard key={e.id} e={e} mark={mark} />)}
      </section>
    </div>
  );
}

function ZoneEditor() {
  const [pts, setPts] = useState([]);
  const [msg, setMsg] = useState("");
  const add = e => {
    const r = e.currentTarget.getBoundingClientRect();
    setPts(p => [...p, [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]]);
  };
  const save = zone =>
    call("/api/cameras/1/zone", "PUT", { zone }).then(r => {
      setMsg(r.error ? r.error : zone ? "Zone saved." : "Zone removed.");
      if (!r.error) setPts([]);
    });
  return (
    <section>
      <h2>Alert zone</h2>
      <p className="muted">Click the corners of the area to watch, one click per corner. The saved zone shows as a green outline.</p>
      <div className="stage draw" onClick={add}>
        <img src="/api/cameras/1/stream" alt="Camera view for drawing the zone" draggable="false" />
        <svg viewBox="0 0 1 1" preserveAspectRatio="none">
          {pts.length > 0 && (
            <polygon points={pts.map(p => p.join(",")).join(" ")} fill="rgba(255,190,0,.25)"
                     stroke="#ffbe00" strokeWidth="3" vectorEffect="non-scaling-stroke" />
          )}
        </svg>
      </div>
      <div className="row">
        <button disabled={pts.length < 3} onClick={() => save(pts)}>Save zone</button>
        <button className="quiet" disabled={!pts.length} onClick={() => setPts(p => p.slice(0, -1))}>Undo last corner</button>
        <button className="quiet" disabled={!pts.length} onClick={() => setPts([])}>Clear drawing</button>
        <button className="quiet" onClick={() => save(null)}>Remove saved zone</button>
        <span className="muted">{pts.length ? `${pts.length} corners` : msg}</span>
      </div>
    </section>
  );
}

function Events({ events, mark }) {
  return (
    <section>
      <h2>Events</h2>
      {events.length === 0 && <p className="muted">No events yet. Draw a zone and arm the system to start watching.</p>}
      <div className="list">{events.map(e => <EventCard key={e.id} e={e} mark={mark} />)}</div>
    </section>
  );
}

export default function App() {
  const [tab, setTab] = useState("live");
  const [health, setHealth] = useHealth();
  const [events, mark] = useEvents();
  const fresh = events.filter(e => e.status === "new").length;
  const toggleArm = () =>
    call("/api/arm", "PUT", { armed: !health.armed }).then(r => setHealth(h => ({ ...h, armed: r.armed })));
  const pickColor = c =>
    call("/api/detector", "PUT", { color: c }).then(r => !r.error && setHealth(h => ({ ...h, color: r.color })));
  const tabs = [["live", "Live view"], ["zone", "Alert zone"], ["events", "Events"]];
  return (
    <div className="app">
      <nav className="rail">
        <div className="brand">Argus</div>
        {tabs.map(([id, label]) => (
          <button key={id} className={"tab" + (tab === id ? " on" : "")} onClick={() => setTab(id)}>
            {label}
            {id === "events" && fresh > 0 && <span className="badge">{fresh}</span>}
          </button>
        ))}
        <div className="spacer" />
        <button className={"arm" + (health?.armed ? " armed" : "")} disabled={!health} onClick={toggleArm}>
          {health?.armed ? "Armed. Tap to disarm" : "Disarmed. Tap to arm"}
        </button>
      </nav>
      <main>
        {tab === "live" && <Live health={health} events={events} mark={mark} pickColor={pickColor} />}
        {tab === "zone" && <ZoneEditor />}
        {tab === "events" && <Events events={events} mark={mark} />}
      </main>
    </div>
  );
}
